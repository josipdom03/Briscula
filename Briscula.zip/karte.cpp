#include"Header.h"


void igra::punjenje()
{
	int i = 0;
	for (i; i < 10; i++)//dinari
	{
		spil[i].zog = "dinar";
		if (i == 0)
		{
			spil[i].broj = "as";
			spil[i].punti = 11;
			spil[i].snaga = 10;
		}
		if (i == 1)
		{
			spil[i].broj = "2";
			spil[i].punti = 0;
			spil[i].snaga = 1;

		}
		if (i == 2)
		{
			spil[i].broj = "3";
			spil[i].punti = 10;
			spil[i].snaga = 9;
		}
		if (i == 3)
		{
			spil[i].broj = "4 ";
			spil[i].punti = 0;
			spil[i].snaga = 2;
		}
		if (i == 4)
		{
			spil[i].broj = "5";
			spil[i].punti = 0;
			spil[i].snaga = 3;
		}
		if (i == 5)
		{
			spil[i].broj = "6";
			spil[i].punti = 0;
			spil[i].snaga = 4;

		}

		if (i == 6)
		{
			spil[i].broj = "7";
			spil[i].punti = 0;
			spil[i].snaga = 5;
		}
		if (i == 7)
		{
			spil[i].broj = "fanat";
			spil[i].punti = 2;
			spil[i].snaga = 6;

		}
		if (i == 8)
		{
			spil[i].broj = "konj";
			spil[i].punti = 3;
			spil[i].snaga = 7;

		}
		if (i == 9)
		{
			spil[i].broj = "kralj";
			spil[i].punti = 4;
			spil[i].snaga = 8;

		}
	}
	for (i; i < 20; i++)//kupe
	{
		spil[i].zog = "kupa";
		if (i == 10)
		{
			spil[i].broj = "as";
			spil[i].punti = 11;
			spil[i].snaga = 10;

		}
		if (i == 11)
		{
			spil[i].broj = "2";
			spil[i].punti = 0;
			spil[i].snaga = 1;

		}
		if (i == 12)
		{
			spil[i].broj = "3";
			spil[i].punti = 10;
			spil[i].snaga = 9;

		}
		if (i == 13)
		{
			spil[i].broj = "4";
			spil[i].punti = 0;
			spil[i].snaga = 2;
		}
		if (i == 14)
		{
			spil[i].broj = "5";
			spil[i].punti = 0;
			spil[i].snaga = 3;
		}
		if (i == 15)
		{
			spil[i].broj = "6";
			spil[i].punti = 0;
			spil[i].snaga = 4;

		}

		if (i == 16)
		{
			spil[i].broj = "7";
			spil[i].punti = 0;
			spil[i].snaga = 5;
		}
		if (i == 17)
		{
			spil[i].broj = "fanat";
			spil[i].punti = 2;
			spil[i].snaga = 6;

		}
		if (i == 18)
		{
			spil[i].broj = "konj";
			spil[i].punti = 3;
			spil[i].snaga = 7;

		}
		if (i == 19)
		{
			spil[i].broj = "kralj";
			spil[i].punti = 4;
			spil[i].snaga = 8;

		}
	}

	for (i; i < 30; i++)//spade
	{
		spil[i].zog = "spade";
		if (i == 20) {


			spil[i].broj = "as";
			spil[i].punti = 11;
			spil[i].snaga = 10;
		}
		if (i == 21)
		{
			spil[i].broj = "2";
			spil[i].punti = 0;
			spil[i].snaga = 1;

		}
		if (i == 22)
		{
			spil[i].broj = "3";
			spil[i].punti = 10;
			spil[i].snaga = 9;

		}
		if (i == 23)
		{
			spil[i].broj = "4";
			spil[i].punti = 0;
			spil[i].snaga = 2;
		}
		if (i == 24)
		{
			spil[i].broj = "5";
			spil[i].punti = 0;
			spil[i].snaga = 3;
		}
		if (i == 25)
		{
			spil[i].broj = "6";
			spil[i].punti = 0;
			spil[i].snaga = 4;

		}

		if (i == 26)
		{
			spil[i].broj = "7";
			spil[i].punti = 0;
			spil[i].snaga = 5;
		}
		if (i == 27)
		{
			spil[i].broj = "fanat";
			spil[i].punti = 2;
			spil[i].snaga = 6;

		}
		if (i == 28)
		{
			spil[i].broj = "konj";
			spil[i].punti = 3;
			spil[i].snaga = 7;

		}
		if (i == 29)
		{
			spil[i].broj = "kralj";
			spil[i].punti = 4;
			spil[i].snaga = 8;

		}
	}


	for (i; i < 40; i++)//bastone
	{
		spil[i].zog = "bastone";
		if (i == 30) {
			spil[i].broj = "as";
			spil[i].punti = 11;
			spil[i].snaga = 10;

		}
		if (i == 31)
		{
			spil[i].broj = "2";
			spil[i].punti = 0;
			spil[i].snaga = 1;

		}
		if (i == 32)
		{
			spil[i].broj = "3";
			spil[i].punti = 10;
			spil[i].snaga = 9;

		}
		if (i == 33)
		{
			spil[i].broj = "4";
			spil[i].punti = 0;
			spil[i].snaga = 2;
		}
		if (i == 34)
		{
			spil[i].broj = "5";
			spil[i].punti = 0;
			spil[i].snaga = 3;
		}
		if (i == 35)
		{
			spil[i].broj = "6";
			spil[i].punti = 0;
			spil[i].snaga = 4;

		}

		if (i == 36)
		{
			spil[i].broj = "7";
			spil[i].punti = 0;
			spil[i].snaga = 5;
		}
		if (i == 37)
		{
			spil[i].broj = "fanat";
			spil[i].punti = 2;
			spil[i].snaga = 6;

		}
		if (i == 38)
		{
			spil[i].broj = "konj";
			spil[i].punti = 3;
			spil[i].snaga = 7;

		}
		if (i == 39)
		{
			spil[i].broj = "kralj";
			spil[i].punti = 4;
			spil[i].snaga = 8;

		}
	}
	
}