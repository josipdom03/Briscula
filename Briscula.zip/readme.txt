Dobrodosao u igru:

						*  *
						 **
		****   ****  *  ****  *   *    *    *  *           *
		*   *  *  *  *  *     *  *     *    *  *          * *
		*   *  *  *  *  *     * *      *    *  *         *   *
		*****  ****  *  ****  * *      *    *  *        * * * *   
		*   *  * *   *     *  *  *     *    *  *	   *       *
		*   *  *  *  *     *  *   *    *    *  *	  *         *
		****   *   * *  ****  *    *   ******  ***** *			 *


Igra je jednostavna konzolna simulacija karta�ke igre bri�kula koja je popularna
na podru�ju Dalmacije i Italije.


Igrica je napravljena u jeziku C++ kao projektni rad za kolegij Objektno programiranje na 
Sveu�ili�nom odjelu za stru�ne studije Sveu�ili�ta u Splitu.

Pravila:

	Postoje 4 zoga:
		1.Kupe
		2.�pade
		3.dinare
		4.ba�tone

	Svaki zog se sastoji od 10 karata koje su poredane po snazi:
			
				karta:						Punti:
				1.As						11
				2.3 - trica					10
				3.kralj						4
				4.konj						3
				5.fanat						2
				6.7							0
				7.6							0
				8.5							0
				9.4							0
				10.2						0

	Uvijek ima prednost karta iz zog koji je predmet igre i karta koja je prije ba�ena ako nije glavni zog ni jedna od 
	ba�enih karata.



	Na po�etku igra� mo�e birati �eli li predizati karte, ako �eli prva polovica �pila se prebacije na 
	kraj.

	Nakon predizanja karte se dijele na dva n�aina:

			1.ako se predi�e - dijeli se jedna  karta igra�u 1 jedna igra�u 2 
			2.ako se ne predi�e tri karte igra�u 1 i 3 karte igra�u 2

	Svaki igra� ima po 3 karte u ruci.


	Zadnja karta u �pilu ozna�ava zog koji je predmet igre.
	Ona je prikazana dok ima karata u �plu a kad nestane ona se vi�e ne prikazuje.

	Ukupan rezultat koji je zbroj svih punata je 120.

	Pobjedink je onaj igra� koji ima zbroj punata ve�i od 60.


Licenca: 

	Ova igra nema licencu jer je ovo narodna karta�ka
	igra koja je prisutna na podru�ju Dalmacije i Italije.



Instalacija:

	Za instalaciju igre potrebno je imati instaliran program Visuala Studio.

	U aplikaciji je potrebno pokrenuti novi projekt.

	Kada se novi projekt u�ita desnim klikom na Source Files ->Add->  Existing Item
			
		Otvara se program u kojem odabirete sljede�e datoteke:

				1.fun.cpp
				2.karte.cpp
				3.petlje.cpp
				4.main.cpp

	Tako�er je potrebno dodati i Header datoteku koja se dodaje 
			
			Header Files ->Add->  Existing Item gdje se odabire:

				1.Header.h

	Datoteke se nalaze u instalacijskoj datoteci briscula.zip.
	Potrebno je samo izvu�i datoteke iz zip mape u �eljenu mapu.

	Nakon u�itavanja svih datoteka dovoljno je pritisnuti Control + F5 za pokretanje bez Debugera ili F5
	za pokretanje s Debugerom.




Mogu�a pobolj�anja igre:

		1. Dodavanje grafi�kog su�elja koje je bolje i pristupa�nije od konzole
		2. Mogu�nost igre s vi�e igra�a putem interneta.
	